import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
data=pd.read_csv("weather.csv")
print(data.head())
