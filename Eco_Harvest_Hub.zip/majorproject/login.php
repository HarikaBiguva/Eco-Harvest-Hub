<?php
include "database.php";
$name=mysqli_real_escape_string($connection,$_POST['loginUser']);
$phone=mysqli_real_escape_string($connection,$_POST['loginnumber']);
$crop=mysqli_real_escape_string($connection,$_POST['cropname']);
$address=mysqli_real_escape_string($connection,$_POST['address']);
$bankaccount=mysqli_real_escape_string($connection,$_POST['password']);
$quantity=mysqli_real_escape_string($connection,$_POST['quantity']);
$cost=mysqli_real_escape_string($connection,$_POST['cost']);
if($connection)
{
	echo "connection established";
}
$query="CREATE TABLE FARMER (NAME VARCHAR(30) NOT NULL, PHONE VARCHAR(15) NOT NULL, CROP VARCHAR(30) NOT NULL,  ADDRESS VARCHAR(30) NOT NULL,BANKACCOUNT VARCHAR(30) NOT NULL,QUANTITY VARCHAR(30) NOT NULL,COST VARCHAR(30) NOT NULL);";
if(mysqli_query($connection,$query))
{
	echo "table created";
}
else
{
	echo "error:".mysqli_error($connection);
}
$query1="INSERT INTO FARMER VALUES('$name','$phone','$crop','$address','$bankaccount','$quantity','$cost');";
if(mysqli_query($connection,$query1))
{
	echo "record inserted"."<br>";
}
else
{
	echo "error:".mysqli_error($connection);
}
$query2="SELECT * FROM FARMER;";
$check=mysqli_query($connection,$query2);
if(mysqli_num_rows($check))
{
	while($row=mysqli_fetch_assoc($check))
	{
		echo $row['NAME']."  ".$row['PHONE']."  ".$row['CROP']."  ".$row['ADDRESS']."  ".$row['BANKACCOUNT']."  ".$row['QUANTITY']."  ".$row['COST']."  "."<br>";
	}
}
header("Location:business.html");

